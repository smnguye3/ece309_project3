# Validation

Linux, GCC 13.3.0, C++17, CMake 4.4.4.

- Build with MH_WERROR=ON: passed with zero warnings.
- P2 regression: 14/14 passed using supplied P2 code.
- P3 suite: 36/36 passed (7 registry, 15 workspace, 14 calculator).
- Provided tool-loop suite: 9/9 passed.
- Golden command-line sessions: 7/7 passed.
- AddressSanitizer and UndefinedBehaviorSanitizer: no findings with
  `ASAN_OPTIONS=detect_leaks=0`.
- LeakSanitizer could not run: this execution environment prevents its process
  inspection. The initial default run passed assertions but failed at process
  exit with a LeakSanitizer environment error. Leak freedom is not independently
  verified; run the default CTest command on ordinary Linux or WSL before
  submission. Sanitizer settings in CMakeLists.txt remain unchanged.

Registry measurement: 10,000 tools; 16,384 buckets; load 0.61035156;
longest FNV-1a chain 6 versus weak-hash chain 9,000.

The only P3 starter code files modified are the registry header/source,
workspace.cpp, calculator_eval.cpp, and the student test suite. README and the
design log are completed, and the four supplied P2 files are copied unchanged.
