# Project 3 Design Log
**Author:** Scarlett Nguyen · **P2 code used:** My own
**AI Assistance**: I had some AI assistance from Codex/ChatGPT for documentation purposes, test development, and troubleshooting errors that I ran across when trying to write code. In addition, I also ran it through once to make sure that every requirement was met.

I had used my own files from the previous project which were the conversation and sentinel scanner implementations, I did not edit them in a major way. 

## Hash Table and Measurements
For my project, I used separate chaining for the registr. The table is a vector of buckets and each bucket is a vector of entries. Each entry stores a cached tool name and a unique_ptr<Tool>. In order to find a tool, the registry will hash its name and search the corresponding bucket. 
I chose chaining because it makes collisions easy to handle and avoids tombstones, while also allowing a load factor of 1.0 without the missing-key lookup issue which can occur in open-address tables. 
The registry starts with 16 buckets and doubles the bucket count before a new distinct insertion pushes the load factor above 1.0. Null and duplicate insertions will return false without changing the number of stored tools or the table size.

I used a 64-bit FNV-1a for the hash. It has a standard offseet basis of 14695981039346656037 and prime of 1099511628211. For each unsigned byte in the name, the hash XORs the byte into its states and then multiplies by the prime. This accounts for characters and order. 
The public hash function returns the full hash value and the registry uses modulo to choose a bucket seperately. 
The standard offset basis is different from the shortened constant, but both mix the full string. 

Testing with `tool_0` through `tool_9999`: 16,384 buckets counted, with a load factor 0.61035156, longest FNV-1a chain was 6, and longest weak-hash chain was 9,000. All 10,000 tool names were found and the first tool kept its original address even after the table grew.

The weak hash groups names by length because their first character is always `t`. 9000 names with  four-digit suffixes all have the same length so they share one bucket. FNV-1a spreads the names out more evenly becausee it also uses the characters in each suffix. 

Rehashing makes the registry recalculate each entry's bucket index using the new bucket count. It counts how many entries have to go into each bucket and reserves the space before moving anything. If the allocation fails then the it avoids partially moving ownership. 

A resize takes O(n) time, but doubling means spreading the cost across many insertions. The total rehash work forms a geometric series, giving insertions an amoprtized expected cost of O(1) when name length is treated as bounded. Hashing a name itself takes O(name length). 

## Pointer Stability and Ownership
Each Tool is owned by a unique_ptr stored in a bucket entry. When a vector grows or a table rehashes, the entries move, but the allocated Tools don't. So a pointer is returned by find will keep the same address through the changes. 

When the registry is destroyed, it destroys each accepted tool once. If add rejects a duplicate, then its by-value unqiue_ptr parameter destroys the rejected tool when the function returns. Leaving the original tool in the registry. The test uses destructor counts to verify this. 

## Calculator Trace
For 2 * (3 + 4) - 5, the calculator uses one stack for values and another for operators (from bottom to top).
Read 2 : values - [2], operators - []
Read * : values -  [2], operators - [*]
Read ( : values - [2], operators - [*, (]
Read 3 : values - [2, 3], operators - [*, (]
Read + : values - [2, 3], operators - [*, (, +]
Read 4 : values - [2, 3, 4], operators - [*, (, +]. 
    At ), apply 3 + 4 and remove (:
        values - [2, 7], operators - [*]. 
    At -, apply the higher-precedence * first:
        values - [14], operators - [-]. 
Read 5 : values - [14, 5], operators - [-].
    At the end, apply subtraction: values - [9], operators - [].

The calculator oppops the right operand before the left operand so subtraction and division use the correct order. It also evaulates operators with equal precedence before pushing to the next one, which makes it evaluate from left to right. 
This is done through loops instead of recursions so that long expression and deep nesting of parentheses does not increase the call-stack usage. 

## Errors and Design Changes
The reason why tools, resolve(), calc_evaluate() retun errors instead of throwing is because problems like missing files, invalid paths, and impossible calculations such as division by zero. Returning an error lets the caller explain the problem and give the model a chance to correct the input. Exceptions are the right choice when it comes to unexpected failures such as memory allocation or a broken internal assumption, which a function cannot continue normally. These are things that are the programmers mistakes.

If I were to revist this and improve the design, I would make the starting bucket count and load factor adjustable. This would make it easier to test how different settings can affect the performance. I would also try to store each entry's hash vallues so rehashing does not need to hash the name again. In adition, I could improve error messages and add more test cases. 