// tests/p3/test_p3.cpp — YOUR P3 TEST SUITE.
//
// required coverage plus ownership and stress tests.
//
// The five tests below are worked examples. Keep them, and add your own
// until you have AT LEAST 15 (spec §6 lists what must be covered).
// Name every test <area>_<what>: reg_ for the registry, ws_ for the
// workspace, calc_ for the calculator.
//
// Build & run:   cmake --build build && ./build/test_p3
// One area:      ./build/test_p3 reg_        (names starting with "reg_")
// One test:      ./build/test_p3 =reg_add_and_find

#include "../mini_test.h"
#include "../test_helpers.h"     // TempDir, write_text, args1, ...

#include "tools/calculator.h"
#include "tools/tool_registry.h"
#include "tools/workspace.h"

#include <algorithm>
#include <cstdio>
#include <memory>
#include <string>
#include <vector>

namespace fs = std::filesystem;

namespace {

// A tool whose name you choose — use it to fill the registry in tests.
class NamedTool : public Tool {
public:
    explicit NamedTool(std::string n) : n_(std::move(n)), schema_(JsonValue::object()) {}
    std::string name() const override { return n_; }
    std::string description() const override { return "test tool"; }
    const JsonValue& schema() const override { return schema_; }
    ToolResult invoke(const JsonValue&, ToolContext&) override { return ToolResult::success(n_); }
private:
    std::string n_;
    JsonValue   schema_;   // an empty JSON object: {}
};

// Tokenize with the provided tokenizer, then run YOUR calc_evaluate.
bool eval(const std::string& expr, double* value, std::string* error) {
    std::vector<CalcToken> tokens;
    if (!calc_tokenize(expr, &tokens, error)) return false;
    return calc_evaluate(tokens, value, error);
}

}  // namespace

// ---------------------------------------------------------------- examples

TEST(reg_add_and_find) {
    ToolRegistry r;
    auto t = std::make_unique<NamedTool>("alpha");
    Tool* raw = t.get();                        // remember the address before moving
    REQUIRE(r.add(std::move(t)));
    CHECK(r.size() == 1);
    CHECK(r.find("alpha") == raw);              // same object, not a copy
    CHECK(r.find("beta") == nullptr);
}

TEST(reg_duplicate_keeps_original) {
    ToolRegistry r;
    auto first = std::make_unique<NamedTool>("alpha");
    Tool* original = first.get();
    REQUIRE(r.add(std::move(first)));
    CHECK(!r.add(std::make_unique<NamedTool>("alpha")));
    CHECK(r.find("alpha") == original);
    CHECK(r.size() == 1);
}

TEST(ws_rejects_parent_escape) {
    TempDir d;
    Workspace ws(d.path());
    fs::path out;
    std::string reason;
    REQUIRE(ws.resolve("notes/todo.txt", &out, &reason));   // sanity: accepts *something*
    CHECK(out == ws.root() / "notes" / "todo.txt");
    CHECK(!ws.resolve("../etc/passwd", &out, &reason));
    CHECK(!reason.empty());
}

TEST(calc_precedence) {
    double v = 0;
    std::string err;
    REQUIRE(eval("2 + 3 * 4", &v, &err));
    CHECK(v == 14);
}

TEST(calc_division_by_zero) {
    double v = 0;
    std::string err;
    CHECK(!eval("1 / 0", &v, &err));
    CHECK(err == "division by zero");
}

// My tests below

TEST(reg_empty_and_null) {
    ToolRegistry r;
    CHECK(r.size() == 0);
    CHECK(r.bucket_count() >= 1 && r.bucket_count() <= 64);
    CHECK(r.load_factor() == 0);
    CHECK(r.max_probe_length() == 0);
    CHECK(!r.add(nullptr));
    CHECK(r.find("absent") == nullptr);
    CHECK(r.size() == 0);
    int visits = 0;
    r.for_each([&](const Tool&) { ++visits; });
    CHECK(visits == 0);
}

TEST(reg_visted_once) {
    ToolRegistry r;
    std::vector<int> visits(100, 0);
    for (int i = 0; i < 100; ++i)
        REQUIRE(r.add(std::make_unique<NamedTool>(std::to_string(i))));
    r.for_each([&](const Tool& t) { ++visits.at(std::stoul(t.name())); });
    for (int count : visits) CHECK(count == 1);
}

TEST(reg_own) {
    struct Counted : NamedTool {
        int& destroyed;
        Counted(int& n) : NamedTool("same"), destroyed(n) {}
        ~Counted() override { ++destroyed; }
    };
    int destroyed = 0;
    {
        ToolRegistry r;
        REQUIRE(r.add(std::make_unique<Counted>(destroyed)));
        CHECK(!r.add(std::make_unique<Counted>(destroyed)));
        CHECK(destroyed == 1);
        CHECK(r.size() == 1);
    }
    CHECK(destroyed == 2);
}

TEST(reg_large_hash_compare) {
    ToolRegistry r;
    Tool* first = nullptr;
    std::vector<std::size_t> hashes;
    for (int i = 0; i < 10000; ++i) {
        std::string name = "tool_" + std::to_string(i);
        REQUIRE(r.add(std::make_unique<NamedTool>(name)));
        if (i == 0) first = r.find(name);
        CHECK(r.load_factor() <= 1.0);
        hashes.push_back(ToolRegistry::hash(name));
    }
    for (int i = 0; i < 10000; ++i)
        CHECK(r.find("tool_" + std::to_string(i)) != nullptr);
    CHECK(r.find("tool_0") == first);
    CHECK(r.find("tool_missing") == nullptr);
    CHECK(r.size() == 10000);
    CHECK(r.max_probe_length() <= 64);
    std::sort(hashes.begin(), hashes.end());
    CHECK(std::unique(hashes.begin(), hashes.end()) - hashes.begin() >= 9990);
    CHECK(ToolRegistry::hash("ab") != ToolRegistry::hash("ba"));
    std::vector<int> weak(r.bucket_count(), 0);
    int longest = 0;
    for (int i = 0; i < 10000; ++i) {
        std::string name = "tool_" + std::to_string(i);
        int n = ++weak[(static_cast<unsigned char>(name[0]) + name.size()) % weak.size()];
        if (n > longest) longest = n;
    }
    CHECK(longest == 9000);
    std::printf("10000 tools: buckets=%zu load=%.8f FNV longest=%zu weak longest=%d\n",
                r.bucket_count(), r.load_factor(), r.max_probe_length(), longest);
}

TEST(reg_same_bucket) {
    ToolRegistry r;
    std::vector<std::string> names;
    for (int i = 0; names.size() < 5; ++i) {
        std::string name = "collision_" + std::to_string(i);
        if (ToolRegistry::hash(name) % r.bucket_count() == 0) names.push_back(name);
    }
    for (const auto& name : names) REQUIRE(r.add(std::make_unique<NamedTool>(name)));
    CHECK(r.max_probe_length() == 5);
    for (const auto& name : names) CHECK(r.find(name) != nullptr);
}

TEST(ws_accept_file) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    REQUIRE(ws.resolve("notes/todo.txt", &out, &reason));
    CHECK(out == ws.root() / "notes/todo.txt");
}

TEST(ws_remove_seperator) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    REQUIRE(ws.resolve("./notes//todo.txt", &out, &reason));
    CHECK(out == ws.root() / "notes/todo.txt");
}

TEST(ws_dot) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    REQUIRE(ws.resolve(".", &out, &reason));
    CHECK(out == ws.root());
}

TEST(ws_simplifiy_parent) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    REQUIRE(ws.resolve("a/../b", &out, &reason));
    CHECK(out == ws.root() / "b");
}

TEST(ws_parent_pair_root) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    REQUIRE(ws.resolve("a/..", &out, &reason));
    CHECK(out == ws.root());
}

TEST(ws_future_files) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    REQUIRE(ws.resolve("new/dir/file.txt", &out, &reason));
    CHECK(out == ws.root() / "new/dir/file.txt");
}

TEST(ws_dots_filename) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    REQUIRE(ws.resolve("my..notes.txt", &out, &reason));
    CHECK(out == ws.root() / "my..notes.txt");
}

TEST(ws_rejects_empty) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    CHECK(!ws.resolve("", &out, &reason)); CHECK(!reason.empty());
}

TEST(ws_rejects_absolute) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    CHECK(!ws.resolve("/etc/passwd", &out, &reason)); CHECK(!reason.empty());
}

TEST(ws_rejects_parent) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    CHECK(!ws.resolve("..", &out, &reason)); CHECK(!reason.empty());
}

TEST(ws_rejects_escape) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    CHECK(!ws.resolve("../etc/passwd", &out, &reason)); CHECK(!reason.empty());
}

TEST(ws_rejects_nested_escape) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    CHECK(!ws.resolve("a/../../b", &out, &reason)); CHECK(!reason.empty());
}

TEST(ws_rejects_reenter) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    CHECK(!ws.resolve("notes/../../ws/notes/todo.txt", &out, &reason)); CHECK(!reason.empty());
}

TEST(ws_rejects_nul) {
    TempDir d; Workspace ws(d.path()); fs::path out; std::string reason;
    const std::string path = std::string("notes") + '\0' + "/x";
    CHECK(!ws.resolve(path, &out, &reason)); CHECK(!reason.empty());
}

TEST(calc_subtract_order) {
    double v = 0; std::string err;
    REQUIRE(eval("10-4-3", &v, &err)); CHECK(v == 3);
}

TEST(calc_divide_order) {
    double v = 0; std::string err;
    REQUIRE(eval("100/10/5", &v, &err)); CHECK(v == 2);
}

TEST(calc_parentheses) {
    double v = 0; std::string err;
    REQUIRE(eval("(2+3)*4", &v, &err)); CHECK(v == 20);
}

TEST(calc_mixed) {
    double v = 0; std::string err;
    REQUIRE(eval("2*(3+4)-5", &v, &err)); CHECK(v == 9);
}

TEST(calc_negative) {
    double v = 0; std::string err;
    REQUIRE(eval("-3*-3", &v, &err)); CHECK(v == 9);
}

TEST(calc_fraction) {
    double v = 0; std::string err;
    REQUIRE(eval("7/2", &v, &err)); CHECK(v == 3.5);
}

TEST(calc_decimals) {
    double v = 0; std::string err;
    REQUIRE(eval("1.25+2.5*2", &v, &err)); CHECK(v == 6.25);
}

TEST(calc_nested) {
    double v = 0; std::string err;
    REQUIRE(eval("((8-2)/(1+2))+4*-2", &v, &err)); CHECK(v == -6);
}

TEST(calc_output_zero) {
    double v = 0; std::string err;
    CHECK(!eval("1/(2-2)", &v, &err)); CHECK(err == "division by zero");
}

TEST(calc_many_terms) {
    std::string expr = "1";
    for (int i = 1; i < 20000; ++i) expr += "+1";
    double v = 0; std::string err;
    REQUIRE(eval(expr, &v, &err)); CHECK(v == 20000);
}

TEST(calc_many_parentheses) {
    std::string expr = std::string(5000, '(') + "7" + std::string(5000, ')');
    double v = 0; std::string err;
    REQUIRE(eval(expr, &v, &err)); CHECK(v == 7);
}

TEST(calc_invalid_tokens) {
    using K = CalcToken::Kind;
    const std::vector<std::vector<CalcToken>> bad = {
        {}, {{K::Plus, 0}}, {{K::RParen, 0}},
        {{K::LParen, 0}, {K::Number, 1}},
        {{K::Number, 1}, {K::Plus, 0}},
        {{K::Number, 1}, {K::Number, 2}},
        {{K::Number, 1}, {K::RParen, 0}}
    };
    for (const auto& tokens : bad) {
        double v = 0; std::string err;
        CHECK(!calc_evaluate(tokens, &v, &err)); CHECK(!err.empty());
    }
}
int main(int argc, char** argv) { return mt::run_all(argc, argv); }
