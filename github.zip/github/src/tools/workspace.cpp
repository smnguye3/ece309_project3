// Lexical path containment, without filesystem I/O

#include "tools/workspace.h"

namespace fs = std::filesystem;

bool Workspace::resolve(std::string_view user_path,
                        fs::path* out,
                        std::string* reason) const {
    auto reject_path = [&](const char* message) {
        if (reason != nullptr) {
            *reason = message;
        }

        return false;
    };

    try {
        if (user_path.empty()) {
            return reject_path("empty path");
        }

        if (user_path.find('\0') != std::string_view::npos) {
            return reject_path("path contains NUL");
        }

        const fs::path requested_path{std::string(user_path)};

        if (requested_path.is_absolute() ||
            requested_path.has_root_path()) {
            return reject_path("absolute paths are not allowed");
        }

        const fs::path normalized_path =
            requested_path.lexically_normal();

        if (normalized_path.begin() != normalized_path.end() &&
            *normalized_path.begin() == "..") {
            return reject_path("path escapes workspace");
        }

        if (out == nullptr) {
            return reject_path("missing output path");
        }

        if (normalized_path == ".") {
            *out = root();
        } else {
            *out = root() / normalized_path;
        }

        if (reason != nullptr) {
            reason->clear();
        }

        return true;
    } catch (...) {
        try {
            return reject_path("invalid path");
        } catch (...) {
            return false;
        }
    }
}