//Custom separate-chaining hash table, FNV-1a, ownership, resizing, instrumentation

#include "tools/tool_registry.h"

#include <cstdint>
#include <utility>

ToolRegistry::ToolRegistry() : buckets_(16) {}

ToolRegistry::~ToolRegistry() = default;

// FNV-1a 
std::size_t ToolRegistry::hash(std::string_view key) noexcept {
    std::uint64_t hash_value = 14695981039346656037ULL;

    for (unsigned char character : key) {
        hash_value ^= character;
        hash_value *= 1099511628211ULL;
    }

    return static_cast<std::size_t>(hash_value);
}

// Allocate destination storage 
void ToolRegistry::rehash(std::size_t count) {
    std::vector<Bucket> new_buckets(count);
    std::vector<std::size_t> bucket_sizes(count, 0);

    for (const auto& chain : buckets_) {
        for (const auto& item : chain) {
            const std::size_t index = hash(item.key) % count;
            ++bucket_sizes[index];
        }
    }

    for (std::size_t index = 0; index < count; ++index) {
        new_buckets[index].reserve(bucket_sizes[index]);
    }

    for (auto& chain : buckets_) {
        for (auto& item : chain) {
            const std::size_t index = hash(item.key) % count;
            new_buckets[index].push_back(std::move(item));
        }
    }

    buckets_.swap(new_buckets);
}

// Add a tool
bool ToolRegistry::add(std::unique_ptr<Tool> tool) {
    if (!tool) {
        return false;
    }

    std::string key = tool->name();

    // Reject the new tool 
    if (find(key) != nullptr) {
        return false;
    }

    if (size_ == buckets_.size()) {
        rehash(buckets_.size() * 2);
    }

    const std::size_t index = hash(key) % buckets_.size();
    auto& chain = buckets_[index];

    chain.push_back(Entry{std::move(key), std::move(tool)});
    ++size_;

    return true;
}

// Search the chain 
Tool* ToolRegistry::find(std::string_view name) const {
    const std::size_t index = hash(name) % buckets_.size();
    const auto& chain = buckets_[index];

    for (const auto& item : chain) {
        if (item.key == name) {
            return item.tool.get();
        }
    }

    return nullptr;
}

std::size_t ToolRegistry::size() const noexcept {
    return size_;
}

std::size_t ToolRegistry::bucket_count() const noexcept {
    return buckets_.size();
}

double ToolRegistry::load_factor() const noexcept {
    return static_cast<double>(size_) /
           static_cast<double>(buckets_.size());
}

// Visit every registered tool exactly once
void ToolRegistry::for_each(
    const std::function<void(const Tool&)>& fn) const {
    for (const auto& chain : buckets_) {
        for (const auto& item : chain) {
            fn(*item.tool);
        }
    }
}

// Separate chaining
std::size_t ToolRegistry::max_probe_length() const {
    std::size_t largest_chain = 0;

    for (const auto& chain : buckets_) {
        const std::size_t chain_length = chain.size();

        if (chain_length > largest_chain) {
            largest_chain = chain_length;
        }
    }

    return largest_chain;
}