// Iterative two-stack evaluation

#include "tools/calculator.h"

#include <stack>

namespace {
using Kind = CalcToken::Kind;

// Multiplication and division 
int precedence(Kind operation) {
    if (operation == Kind::Times || operation == Kind::Divide) {
        return 2;
    }

    if (operation == Kind::Plus || operation == Kind::Minus) {
        return 1;
    }

    return 0;
}
}

bool calc_evaluate(const std::vector<CalcToken>& tokens,
                   double* out,
                   std::string* error) {
    std::stack<double> numbers;
    std::stack<Kind> operators;

    auto report_error = [&](const char* message) {
        if (error != nullptr) {
            *error = message;
        }

        return false;
    };

    // Most recent operator to the top two numbers
    auto apply_operator = [&]() {
        if (operators.empty() || numbers.size() < 2) {
            return report_error("missing operand");
        }

        const Kind operation = operators.top();
        operators.pop();

        const double right = numbers.top();
        numbers.pop();

        const double left = numbers.top();
        numbers.pop();

        switch (operation) {
            case Kind::Plus:
                numbers.push(left + right);
                break;

            case Kind::Minus:
                numbers.push(left - right);
                break;

            case Kind::Times:
                numbers.push(left * right);
                break;

            case Kind::Divide:
                if (right == 0.0) {
                    return report_error("division by zero");
                }

                numbers.push(left / right);
                break;

            default:
                return report_error("invalid operator");
        }

        return true;
    };

    bool expecting_number = true;

    for (const auto& token : tokens) {
        if (token.kind == Kind::Number) {
            if (!expecting_number) {
                return report_error("missing operator");
            }

            numbers.push(token.value);
            expecting_number = false;
        } else if (token.kind == Kind::LParen) {
            if (!expecting_number) {
                return report_error("missing operator");
            }

            operators.push(token.kind);
        } else if (token.kind == Kind::RParen) {
            if (expecting_number) {
                return report_error("missing operand");
            }

            while (!operators.empty() &&
                   operators.top() != Kind::LParen) {
                if (!apply_operator()) {
                    return false;
                }
            }

            if (operators.empty()) {
                return report_error("unmatched parenthesis");
            }

            operators.pop();
        } else {
            if (expecting_number || precedence(token.kind) == 0) {
                return report_error("invalid operator or missing operand");
            }

            // Equal precedence
            while (!operators.empty() &&
                   operators.top() != Kind::LParen &&
                   precedence(operators.top()) >= precedence(token.kind)) {
                if (!apply_operator()) {
                    return false;
                }
            }

            operators.push(token.kind);
            expecting_number = true;
        }
    }

    if (expecting_number) {
        return report_error("missing operand");
    }

    while (!operators.empty()) {
        if (operators.top() == Kind::LParen) {
            return report_error("unmatched parenthesis");
        }

        if (!apply_operator()) {
            return false;
        }
    }

    if (numbers.size() != 1 || out == nullptr) {
        return report_error("invalid result");
    }

    *out = numbers.top();

    if (error != nullptr) {
        error->clear();
    }

    return true;
}