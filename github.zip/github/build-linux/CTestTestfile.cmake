# CMake generated Testfile for 
# Source directory: /mnt/c/Users/nguye/Downloads/git/github
# Build directory: /mnt/c/Users/nguye/Downloads/git/github/build-linux
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.
add_test(p2_regression "/mnt/c/Users/nguye/Downloads/git/github/build-linux/test_p2")
set_tests_properties(p2_regression PROPERTIES  WORKING_DIRECTORY "/mnt/c/Users/nguye/Downloads/git/github/build-linux" _BACKTRACE_TRIPLES "/mnt/c/Users/nguye/Downloads/git/github/CMakeLists.txt;82;add_test;/mnt/c/Users/nguye/Downloads/git/github/CMakeLists.txt;0;")
add_test(p3 "/mnt/c/Users/nguye/Downloads/git/github/build-linux/test_p3")
set_tests_properties(p3 PROPERTIES  WORKING_DIRECTORY "/mnt/c/Users/nguye/Downloads/git/github/build-linux" _BACKTRACE_TRIPLES "/mnt/c/Users/nguye/Downloads/git/github/CMakeLists.txt;86;add_test;/mnt/c/Users/nguye/Downloads/git/github/CMakeLists.txt;0;")
add_test(tool_loop "/mnt/c/Users/nguye/Downloads/git/github/build-linux/test_loop")
set_tests_properties(tool_loop PROPERTIES  WORKING_DIRECTORY "/mnt/c/Users/nguye/Downloads/git/github/build-linux" _BACKTRACE_TRIPLES "/mnt/c/Users/nguye/Downloads/git/github/CMakeLists.txt;90;add_test;/mnt/c/Users/nguye/Downloads/git/github/CMakeLists.txt;0;")
add_test(e2e "bash" "/mnt/c/Users/nguye/Downloads/git/github/tests/e2e/run_e2e.sh" "/mnt/c/Users/nguye/Downloads/git/github/build-linux/miniharness")
set_tests_properties(e2e PROPERTIES  WORKING_DIRECTORY "/mnt/c/Users/nguye/Downloads/git/github" _BACKTRACE_TRIPLES "/mnt/c/Users/nguye/Downloads/git/github/CMakeLists.txt;99;add_test;/mnt/c/Users/nguye/Downloads/git/github/CMakeLists.txt;0;")
